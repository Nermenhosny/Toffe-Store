
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Hashtable;

public class Main
{
    public static void main(String[] args)
    {
        // Create a new orderManager object
        UserManagementMenu menu = new UserManagementMenu();
         menu.displayMenu();
    }
}


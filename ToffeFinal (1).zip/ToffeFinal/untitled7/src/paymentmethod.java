import org.w3c.dom.xpath.XPathResult;

import java.util.Scanner;

public interface paymentmethod {
    void makepayment(order o);
}

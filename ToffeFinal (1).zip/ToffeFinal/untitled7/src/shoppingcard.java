import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class shoppingcard
{
    private Item item;
    order ord;
    private int cardid;
    private int customerid;
    private String customeradress;
    private Date getlasacess;
    public HashMap<Item, Integer> cartitems= new HashMap<Item, Integer>();
    public Items it=new Items();

    public void additem(int itemid,int quantity)
    {
        for( Item i:it.getItemList())
        {
            if(i.getItemid()==itemid)
            {
                cartitems.put(i,quantity);

            }
        }
    }
    public void removeitem(int itemid){
        for( Item i:it.getItemList()) {
            if(i.getItemid()==itemid){
                cartitems.remove(i);
            }
        }
    }

    public HashMap<Item, Integer> viewitems(){
        return cartitems;
    }

public void checkout(order myOrder){
    for(Entry<Item, Integer> entry: cartitems.entrySet()) {
        Item key = entry.getKey();
        int value = entry.getValue();
        ord.addOrderDetail(key,value);
    }
    int d=0;
System.out.println("choose your payment method");
    System.out.println("1-cash");
    System.out.println("2-credit");
    System.out.println("3-smartwallet");
    Scanner in = new Scanner(System.in);
    d=in.nextInt();
    if(d==1){
        cash c=new cash();
        c.makepayment(ord);
    }
    else if(d==2){
        credit c=new credit();
        c.makepayment(ord);
    }
    else if(d==3){
        smartwallet s=new smartwallet();
        s.makepayment(ord);
    }
    else{
        System.out.println("invalid choice");
    }

}
    public  HashMap<Item, Integer> getcard(){
        HashMap<Item, Integer> items=new HashMap<Item, Integer>();
        for(Entry<Item, Integer> entry: cartitems.entrySet()) {
            Item key = entry.getKey();
            int value = entry.getValue();
            items.put(key,value);
        }

        return items;
    }
public double calculatetotal(){
  double total=0;
    for(Entry<Item, Integer> entry: cartitems.entrySet()) {
        Item key = entry.getKey();
        int value = entry.getValue();
        total+= (key.getPrice()*value);

    }
return total;
}
public int getCustomerid(){
        return customerid;
}

    public int countitems(){
        int totalitems=0;
        for(Entry<Item, Integer> entry: cartitems.entrySet()) {
            Item key = entry.getKey();
            int value = entry.getValue();
            totalitems+=value;

        }
        return totalitems;
    }


}
